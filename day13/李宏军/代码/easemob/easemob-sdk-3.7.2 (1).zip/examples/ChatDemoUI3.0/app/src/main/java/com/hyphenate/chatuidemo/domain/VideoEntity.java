package com.hyphenate.chatuidemo.domain;

import android.net.Uri;

public class VideoEntity {
	public int ID;
	public String title;
	public String filePath;
	public int size;
	public int duration;
	public Uri uri;
}
