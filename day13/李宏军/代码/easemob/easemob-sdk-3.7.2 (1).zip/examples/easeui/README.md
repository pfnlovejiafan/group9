# easeui

## 简介
EaseUI是一个基于环信sdk的UI库，封装了IM功能常用的控件、fragment等等。此项目包含一个简单使用的demo：simpledemo，开发者可导出查看。
github上的代码不包含环信sdk，需要依赖环信IM 3.x版本的SDK使用，建议与环信的IM demo一起使用。

## 关于分支
master分支(也就是默认分支)是环信sdk 2.x版本的稳定代码，3.x版本的代码在sdk3.0分支上，看自己需求切换分支。另外sdk3.0这是一个开发中的分支，release版本分别有相应分支或tag。

## 相关文档
请参考相关的集成说明：http://docs-im.easemob.com/im/android/sdk/import
